var modal = document.querySelector('#modal');

// modal.style.display = 'none';
